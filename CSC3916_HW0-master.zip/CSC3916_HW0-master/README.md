# week1
# CSC3916_HW0
[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/e2333f9d937b86dab2d8#?env%5BSheikhHW0%5D=W3sia2V5IjoiYm9va190aXRsZSIsInZhbHVlIjoiVHVyaW5nIiwiZW5hYmxlZCI6dHJ1ZX0seyJrZXkiOiJpZCIsInZhbHVlIjoiUW5VUEJBQUFRQkFKIiwiZW5hYmxlZCI6dHJ1ZX1d)
